Hello, and Welcome to miniBB!

miniBB forum software project is at the top of our programming ideas, and we are very happy, that you have chosen our product within hundreds of others. If you are going to install it, first of all, you need to know some miniBB requirements:

1) A web server, with PHP and mySQL installed - this program doesn't run as Windows standalone;
2) Knowing your mySQL host, login and password;
3) A minimal imagination about general principles of bulletin board software operation.

Please, read the installation instructions in our manual, which can be found here:

WEB: http://www.minibb.com/forums/index.php?action=manual#config1

LOCALLY: /templates/manual_eng.html

In manual, you will also find a lot of interesting stuff about miniBB.

Our software is FREE, which means - when you download, install and run the default version, you don't need to pay anything to anyone. By General Public License conditions, only little copyright notice must be kept, identifying you as honest and reliable client of the Open Source World.

Despite that, if you:

- need help in installing this forum software on your site,
- want to make advanced customizations to this software,
- want to make custom non-core-destructive add-ons to this software,
- want to make your forums layout completely fitting to your site,
- want to unite this forums software with an existing users database,

then, please, pay attention to our "Paid Support" section:

http://www.minibb.com/paid_support.html

We are always providing HONEST, ACCURATE and FASTEST possible service regarding any miniBB custom work.

Also visit our free support Live Forums, where you may find a lot of custom solutions and answers, regarding our forum software:

http://www.minibb.com/forums/

When you will run an active live community (and we're sure, with this forum software you WILL!) - don't forget to provide a reciprocal LINK to your forums, so it appears in our Showcase Section and makes Google bot more happy with your project:

http://www.minibb.com/sites.html

And if you are proud of your graphical integration, just drop as a note about this, so we mention it in our virtual miniBB Gallery:

http://www.minibb.com/gallery.html

Thank you for choosing miniBB!

Enjoy using our software :-)

//miniBB Team